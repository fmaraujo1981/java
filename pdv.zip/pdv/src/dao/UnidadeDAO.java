package dao;
import factory.ConnectionFactory;
import modelo.Unidade;
import java.sql.*;
import java.sql.PreparedStatement;
public class UnidadeDAO { 
    private Connection connection;
    Long id;
    String nome;
    
    public UnidadeDAO(){ 
        this.connection = new ConnectionFactory().getConnection();
    } 
    public void adiciona(Unidade unidade){ 
        String sql = "INSERT INTO unidade(descricao) VALUES(?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, unidade.getDescricao());
            
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    } 
    
}