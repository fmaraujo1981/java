package modelo;
public class Produto {
    Long idproduto;
    String descricao;
    String detalhes;
    String imagem;
    Float valor;
    Integer unidade_idunidade;
    
    public Long getId() {
        return idproduto;
    }
    public void setId(Long idproduto) {
        this.idproduto = idproduto;
    } 
    public String getDescricao() { 
        return descricao;
    } 
    public void setDescricao(String descricao) { 
        this.descricao = descricao;
    }
    
    public String getDetalhes() { 
        return detalhes;
    } 
    public void setDetalhes(String detalhes) { 
        this.detalhes = detalhes;
    }
    
  public String getImagem() { 
        return imagem;
    } 
    public void setImagem(String imagem) { 
        this.imagem = imagem;
    }
    
    public Float getValor() { 
        return valor;
    } 
    public void setValor(Float valor) { 
        this.valor = valor;
    }
    
     public Integer getUnidade_idunidade() {
        return unidade_idunidade;
    }
    public void setUnidade_idunidade(Integer unidade_idunidade) {
        this.unidade_idunidade = unidade_idunidade;
    } 
    
    
}