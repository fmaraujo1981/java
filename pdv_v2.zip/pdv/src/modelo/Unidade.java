package modelo;
public class Unidade {
    Long idunidade;
    String descricao;
    
    
    public Long getId() {
        return idunidade;
    }
    public void setId(Long idunidade) {
        this.idunidade = idunidade;
    } 
    public String getDescricao() { 
        return descricao;
    } 
    public void setDescricao(String descricao) { 
        this.descricao = descricao;
    } 
    

}