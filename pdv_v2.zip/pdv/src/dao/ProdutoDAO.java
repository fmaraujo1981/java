package dao;
import factory.ConnectionFactory;
import modelo.Produto;
import java.sql.*;
import java.sql.PreparedStatement;
public class ProdutoDAO { 
    private Connection connection;
    Long id;
    String descricao;
    
    String detalhes;
    String imagem;
    Float valor;
    Long unidade_idunidade;
    
    public ProdutoDAO(){ 
        this.connection = new ConnectionFactory().getConnection();
    } 
    public void adiciona(Produto produto){ 
        String sql = "INSERT INTO Produto(descricao,detalhes,imagem,valor,unidade_idunidade) VALUES(? ? ? ? ?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, produto.getDescricao());
            stmt.setString(2, produto.getDetalhes());
            stmt.setString(3, produto.getImagem());
            stmt.setString(4, String.valueOf( new Double(produto.getValor())));
            stmt.setString(4, String.valueOf(produto.getUnidade_idunidade()));

            
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    } 
    
}